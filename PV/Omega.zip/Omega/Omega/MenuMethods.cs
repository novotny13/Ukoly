﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal class MenuMethods
    {
        public IEnumerable<Objednavka> GetByZakaznik(Zakaznik zak)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Objednavka " +
                "WHERE Objednavka.ID IN" +
                "(SELECT Objednavka.ID FROM Objednavka innre join Zakaznik on Objednavka.zakaznikID = Zakaznik.id " +
                "WHERE Zakaznik.id = @id)", conn))
            {
                command.Parameters.Add(new SqlParameter("@id", zak.ID));
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Objednavka obj = new Objednavka
                    {
                        ID = Convert.ToInt32(reader[0].ToString()),
                        
                    };
                    yield return obj;
                }
                reader.Close();
            }
        }

        public IEnumerable<Produkt> GetByKategorie(Kategorie kat)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Produkt " +
                "WHERE Produkt.ID IN" +
                "(SELECT Produkt.ID FROM Produkt innre join Kategorie on Kategorie.ID = Produkt.categoryId " +
                "WHERE Zakaznik.id = @id)", conn))
            {
                command.Parameters.Add(new SqlParameter("@id", kat.ID));
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Produkt obj = new Produkt
                    {
                        ID = Convert.ToInt32(reader[0].ToString()),
                        Name = reader[1].ToString(),

                    };
                    yield return obj;
                }
                reader.Close();
            }
        }


        public IEnumerable<Zakaznik> getAllZakaznici()
        {
          
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Zakaznik ", conn))
            {

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Zakaznik pepa = new Zakaznik
                    {
                        ID = Convert.ToInt32(reader[0].ToString()),
                        Name = reader[1].ToString(),
                        Email = reader[2].ToString(),
                    };
                    yield return pepa;
                    
                }
                reader.Close();
            }
            
        }

        /*
         var numList = new List<int>()
{
    1, 4, 5, 7, 4, 10
};

foreach (var result in SumOfNums(numList))
{
    Console.WriteLine(result);
}

IEnumerable<int> SumOfNums(List<int> nums)
{
    var sum = 0;
    foreach (var num in nums)
    { 
        sum += num;
        yield return sum;
    }
}
         * */







        /*
         private void btnRegister_Click(object sender, EventArgs e)
        {
            ToggleWelcomeScreen(false);
            ShowRegisterForm(true);
        }
        private List <Zakaznik> users = new List <Zakaznik>();
       
          */











    }
}
