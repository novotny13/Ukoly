﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    public class Zakaznik : IBaseClass
    {
        private int id;
        private string name;
        private string email;

        public int ID { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public string Email { get => email; set => email = value; }

        public Zakaznik(int id, string name, string email)
        {
            ID = id;
            Name = name;
            Email = email;
        }

        public Zakaznik(string name, string email)
        {
            ID = 0;
            Name = name;
            Email = email;
        }

        public Zakaznik() { }

        public override string ToString()
        {
            return $"{name} - {email}";
        }
    }
}
