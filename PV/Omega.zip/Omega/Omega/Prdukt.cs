﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    public class Produkt : IBaseClass
    {
        private int id;
        private string name;
        private float price;
        private int categoryId; 

        public int ID { get => id; set => id = value; }
        public string Name { get => name; set => name = value; }
        public float Price { get => price; set => price = value; }
        public int CategoryID { get => categoryId; set => categoryId = value; } 
        public Produkt(int id, string name, float price, int categoryId)
        {
            ID = id;
            Name = name;
            Price = price;
            CategoryID = categoryId;
        }

        public Produkt(string name, float price, int categoryId)
        {
            ID = 0;
            Name = name;
            Price = price;
            CategoryID = categoryId;
        }

        public Produkt() { }

        public override string ToString()
        {
            return $"{name} - {price}";
        }
    }
}
