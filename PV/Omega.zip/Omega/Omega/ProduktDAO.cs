﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    public class ProduktDAO : IRepository<Produkt>
    {
        // Připojení k databázi
       

        // Metoda pro vložení produktu do databáze
        public void Insert(Produkt produkt)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("INSERT INTO Produkt (Name, Price, CategoryID) VALUES (@Name, @Price, @CategoryID)", conn))
            {
                
                command.Parameters.AddWithValue("@Name", produkt.Name);
                command.Parameters.AddWithValue("@Price", produkt.Price);
                command.Parameters.AddWithValue("@CategoryID", produkt.CategoryID);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro smazání produktu z databáze
        public void Delete(Produkt produkt)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("DELETE FROM Produkt WHERE ID = @ID", conn))
            {
                
                command.Parameters.AddWithValue("@ID", produkt.ID);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro úpravu produktu v databáze
        public void Update(Produkt produkt)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("UPDATE Produkt SET Name = @Name, Price = @Price, CategoryID = @CategoryID WHERE ID = @ID", conn))
            {
              
                command.Parameters.AddWithValue("@ID", produkt.ID);
                command.Parameters.AddWithValue("@Name", produkt.Name);
                command.Parameters.AddWithValue("@Price", produkt.Price);
                command.Parameters.AddWithValue("@CategoryID", produkt.CategoryID);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro získání všech produktů z databáze

        public IEnumerable<int> GetAllID()
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT ID FROM Produkt", conn))
            {


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    int ID;
                    {
                        ID = (int)reader["ID"];
                       

                    };
                    yield return ID;
                }

            }


        }
        public IEnumerable<Produkt> GetAll()
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Produkt", conn))
            {


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Produkt produkt = new Produkt
                    {
                        ID = (int)reader["ID"],
                        Name = (string)reader["Name"],
                        Price = (float)reader["Price"],
                        CategoryID = (int)reader["CategoryID"]

                    };
                    yield return produkt;
                }

            }


        }
    }
}