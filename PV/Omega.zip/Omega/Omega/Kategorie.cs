﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Omega
{
    internal class Kategorie : IBaseClass
    {
        public int ID { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }


        public string name;
        public string Name { get => name; set => name = value; }

        public Kategorie(int id, string name)
        {
            ID = id;
            Name = name;
           
        }

        public Kategorie(string name)
        {
            ID = 0;
            Name = name;
           
        }

        public Kategorie() { }

        public override string ToString()
        {
            return $"{name} - {ID}";
        }

    }
}
