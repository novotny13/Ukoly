﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal interface IRepository<T> where T : IBaseClass
    {

    
        IEnumerable<T> GetAll();
        void Insert(T element);
        void Delete(T element);

    }
}
