﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Drawing;

namespace Omega
{
    public class LoginForm : Form
    {
        private Label lblWelcome;
        private Button btnLogin;
        private Button btnRegister;
        private Label lblEmail;
        private Label lblName;
        private TextBox txtEmail;
        private TextBox txtName;
        private Button btnSubmitLogin;
        private Button btnSubmitRegister;
        private Button btnBack;

        private Form shopForm;
        private List<Produkt> objednavka;
        List<Zakaznik> users = new List<Zakaznik>();
        ProduktDAO pDAO = new ProduktDAO();
        ObjednavkaDAO objDAO = new ObjednavkaDAO();
        ObjednavkaPolozkaDAO objPolozkaDAO = new ObjednavkaPolozkaDAO();
        ZakaznikDAO zakDAO = new ZakaznikDAO(); 
        public LoginForm()
        {
            
            this.Text = "Login/Register Form";
            this.Size = new Size(1000, 700);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;

            
            objednavka = new List<Produkt>();

      
            lblWelcome = new Label();
            lblWelcome.Text = "Vítejte";
            lblWelcome.Font = new Font("Microsoft Sans Serif", 24F);
            lblWelcome.AutoSize = true;
            lblWelcome.Location = new Point(400, 50);

            btnLogin = new Button();
            btnLogin.Text = "Login";
            btnLogin.Location = new Point(300, 150);
            btnLogin.Size = new Size(100, 50);
            btnLogin.Click += new EventHandler(this.btnLogin_Click);

            btnRegister = new Button();
            btnRegister.Text = "Register";
            btnRegister.Location = new Point(600, 150);
            btnRegister.Size = new Size(100, 50);
            btnRegister.Click += new EventHandler(this.btnRegister_Click);

            lblEmail = new Label();
            lblEmail.Text = "Email";
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(300, 250);
            lblEmail.Visible = false;

            lblName = new Label();
            lblName.Text = "Name";
            lblName.AutoSize = true;
            lblName.Location = new Point(300, 290);
            lblName.Visible = false;

            txtEmail = new TextBox();
            txtEmail.Location = new Point(400, 250);
            txtEmail.Size = new Size(300, 20);
            txtEmail.Visible = false;

            txtName = new TextBox();
            txtName.Location = new Point(400, 290);
            txtName.Size = new Size(300, 20);
            txtName.Visible = false;

            btnSubmitLogin = new Button();
            btnSubmitLogin.Text = "Submit Login";
            btnSubmitLogin.Location = new Point(400, 330);
            btnSubmitLogin.Size = new Size(100, 30);
            btnSubmitLogin.Visible = false;
            btnSubmitLogin.Click += new EventHandler(this.btnSubmitLogin_Click);

            btnSubmitRegister = new Button();
            btnSubmitRegister.Text = "Submit Register";
            btnSubmitRegister.Location = new Point(400, 330);
            btnSubmitRegister.Size = new Size(100, 30);
            btnSubmitRegister.Visible = false;
            btnSubmitRegister.Click += new EventHandler(this.btnSubmitRegister_Click);

            btnBack = new Button();
            btnBack.Text = "Zpět";
            btnBack.Location = new Point(400, 380);
            btnBack.Size = new Size(100, 30);
            btnBack.Visible = false;
            btnBack.Click += new EventHandler(this.btnBack_Click);

          
            this.Controls.Add(lblWelcome);
            this.Controls.Add(btnLogin);
            this.Controls.Add(btnRegister);
            this.Controls.Add(lblEmail);
            this.Controls.Add(lblName);
            this.Controls.Add(txtEmail);
            this.Controls.Add(txtName);
            this.Controls.Add(btnSubmitLogin);
            this.Controls.Add(btnSubmitRegister);
            this.Controls.Add(btnBack);
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            ToggleWelcomeScreen(false);
            ShowLoginForm(true);
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            ToggleWelcomeScreen(false);
            ShowRegisterForm(true);
        }
        /*
        private void btnSubmitLogin_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Login Submitted");
            ShowShopForm();
        }

        private void btnSubmitRegister_Click(object sender, EventArgs e)
        {
            
            MessageBox.Show("Register Submitted");
        }
        */
        Zakaznik karel = new Zakaznik("", "");
        private void btnSubmitLogin_Click(object sender, EventArgs e)
        {
            bool ok = false;
            MenuMethods mn = new MenuMethods();
            foreach (var result in mn.getAllZakaznici())
            {
                users.Add(result);
            }
             karel = new Zakaznik(txtName.Text, txtEmail.Text);
            foreach (var item in users)
            {
                if (karel.ToString() == item.ToString())
                {
                    ok = true;
                }
            }
            {

            }
            if (ok)
            {
                ShowShopForm();
            }
        }

        private void btnSubmitRegister_Click(object sender, EventArgs e)
        {
            Zakaznik karel2 = new Zakaznik(txtName.Text, txtEmail.Text);
            ZakaznikDAO karel2DAO = new ZakaznikDAO();
            karel2DAO.Insert(karel2);
            MessageBox.Show("Register Submitted");
            ShowLoginForm(true);
        }

         
        private void btnBack_Click(object sender, EventArgs e)
        {
            ShowLoginForm(false);
            ShowRegisterForm(false);
            ToggleWelcomeScreen(true);
        }

        private void ToggleWelcomeScreen(bool show)
        {
            lblWelcome.Visible = show;
            btnLogin.Visible = show;
            btnRegister.Visible = show;
        }

        private void ShowLoginForm(bool show)
        {
            lblEmail.Visible = show;
            txtEmail.Visible = show;
            btnSubmitLogin.Visible = show;
            btnBack.Visible = show;
        }

        private void ShowRegisterForm(bool show)
        {
            lblEmail.Visible = show;
            txtEmail.Visible = show;
            lblName.Visible = show;
            txtName.Visible = show;
            btnSubmitRegister.Visible = show;
            btnBack.Visible = show;
        }

        private void ShowShopForm()
        {
            shopForm = new Form();
            shopForm.Text = "Obchod";
            shopForm.Size = new Size(1000, 700);
            shopForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            shopForm.MaximizeBox = false;

            Label lblShop = new Label();
            lblShop.Text = "Obchod";
            lblShop.Font = new Font("Microsoft Sans Serif", 24F);
            lblShop.AutoSize = true;
            lblShop.Location = new Point(450, 50);

            Button btnOrder = new Button();
            btnOrder.Text = "Objednávka";
            btnOrder.Location = new Point(850, 20);
            btnOrder.Size = new Size(100, 30);
            btnOrder.Click += new EventHandler(this.btnOrder_Click);

            Button btnSubmitOrder = new Button();
            btnSubmitOrder.Text = "Odeslat objednávku";
            btnSubmitOrder.Location = new Point(450, 600);
            btnSubmitOrder.Size = new Size(200, 50);
            btnSubmitOrder.Click += new EventHandler(this.btnSubmitOrder_Click);

            shopForm.Controls.Add(lblShop);
            shopForm.Controls.Add(btnOrder);
            shopForm.Controls.Add(btnSubmitOrder);

            string[] items = { "Lezecka soma", "60M Lano", "Smyce", "Sedak", "Lezecke boty" };
            for (int i = 0; i < items.Length; i++)
            {
                PictureBox pictureBox = new PictureBox();
                pictureBox.Size = new Size(100, 100);
                pictureBox.Location = new Point(150 + (i * 150), 150);
                pictureBox.BackColor = Color.Gray; 

                Label lblItem = new Label();
                lblItem.Text = items[i];
                lblItem.AutoSize = true;
                lblItem.Location = new Point(150 + (i * 150), 260);

                Button btnAddToOrder = new Button();
                btnAddToOrder.Text = "Přidat do objednávky";
                btnAddToOrder.Location = new Point(150 + (i * 150), 290);
                btnAddToOrder.Size = new Size(100, 30);
                btnAddToOrder.Tag = new Produkt(items[i], 500.0f + i *5, 1); 
                btnAddToOrder.Click += new EventHandler(this.btnAddToOrder_Click);

                shopForm.Controls.Add(pictureBox);
                shopForm.Controls.Add(lblItem);
                shopForm.Controls.Add(btnAddToOrder);
            }

            shopForm.Show();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            ShowOrderForm();
        }

        private void btnAddToOrder_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            Produkt produkt = btn.Tag as Produkt;
            objednavka.Add(produkt);
            
        }

        private void ShowOrderForm()
        {
            Form orderForm = new Form();
            orderForm.Text = "Objednávka";
            orderForm.Size = new Size(500, 500);
            orderForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            orderForm.MaximizeBox = false;

            ListBox lstOrder = new ListBox();
            lstOrder.Location = new Point(50, 50);
            lstOrder.Size = new Size(400, 300);
            foreach (var produkt in objednavka)
            {
                lstOrder.Items.Add(produkt);
            }

            Button btnRemove = new Button();
            btnRemove.Text = "Odstranit položku";
            btnRemove.Location = new Point(50, 370);
            btnRemove.Size = new Size(120, 30);
            btnRemove.Click += (s, e) =>
            {
                if (lstOrder.SelectedItem != null)
                {
                    objednavka.Remove((Produkt)lstOrder.SelectedItem);
                    lstOrder.Items.Remove(lstOrder.SelectedItem);
                }
            };

            orderForm.Controls.Add(lstOrder);
            orderForm.Controls.Add(btnRemove);

            orderForm.Show();
        }

        private void btnSubmitOrder_Click(object sender, EventArgs e)
        {
            foreach(var pro in objednavka)
            {
                pDAO.Insert(pro);
            }
            int zakID = zakDAO.GetID(karel);
            
            Objednavka order = new Objednavka( zakID);
            int obnjID = objDAO.GetID(karel);
            List<int> IDlist = new List<int>();
            objDAO.Insert(order);

            foreach(var x in pDAO.GetAllID())
            {
                IDlist.Add(x);
            }
            for (int i = 0; i < objednavka.Count(); i++)
            {
                objPolozkaDAO.Insert2(IDlist[i], obnjID);
            }
            shopForm.Controls.Clear();

            Label lblThankYou = new Label();
            lblThankYou.Text = "Děkujeme za objednávku";
            lblThankYou.Font = new Font("Microsoft Sans Serif", 24F);
            lblThankYou.AutoSize = true;
            lblThankYou.Location = new Point(350, 300);

            shopForm.Controls.Add(lblThankYou);
        }
    }

   

   
}
