﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal class ObjednavkaDAO : IRepository<Objednavka>
    {

        public int GetID(Zakaznik zakaznik)
        {
            int ID = 0;
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT ID from Objednavka where zakaznik_ID = @ID", conn))
            {

                command.Parameters.AddWithValue("@ID", zakaznik.ID);
                
                command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    ID = (int)reader["ID"];

                }
            }
            return ID;
        }

        // Metoda pro vložení objednávky do databáze
        public void Insert(Objednavka objednavka)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("INSERT INTO Objednavka (ZakaznikID) VALUES (@ZakaznikID)", conn))
            {
               
                command.Parameters.AddWithValue("@ZakaznikID", objednavka.ZakaznikID);
                
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro smazání objednávky z databáze
        public void Delete(Objednavka objednavka)
        {

            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("DELETE FROM Objednavka WHERE ID = @ID", conn))
            {
            
                command.Parameters.AddWithValue("@ID", objednavka.ID);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro úpravu objednávky v databáze
        public void Update(Objednavka objednavka)
        {

            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("UPDATE Objednavka SET ZakaznikID = @ZakaznikID WHERE ID = @ID", conn))
            {

               
                command.Parameters.AddWithValue("@ID", objednavka.ID);
                command.Parameters.AddWithValue("@ZakaznikID", objednavka.ZakaznikID);
               
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro získání všech objednávek z databáze
      


        public IEnumerable<Objednavka> GetAll()
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Objednavka", conn))
            {


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Objednavka objednavka = new Objednavka
                    {
                        ID = (int)reader["ID"],
                        ZakaznikID = (int)reader["ZakaznikID"],
                        
                    };
                    yield return objednavka;
                }

            }


        }
    }
}
