﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal class Objednavka_Polozka : IBaseClass
    {
        
            private int orderId;
            private int productCISLO;
            

            public int OrderID { get => orderId; set => orderId = value; }
            public int ProductCISLO { get => productCISLO; set => productCISLO = value; }
           
        public int ID { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public Objednavka_Polozka(int orderId, int productCISLO)
            {
                OrderID = orderId;
                ProductCISLO = productCISLO;
                
            }

            public Objednavka_Polozka() { }

            public override string ToString()
            {
                return $"Order ID: {orderId}, Product ID: {productCISLO}";
            }
        }
    
}
