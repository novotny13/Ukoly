﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Omega
{
    internal class Objednavka : IBaseClass
    {
        private int id;
        private int zakaznikID;
       

        public int ID { get => id; set => id = value; }
        
        public int ZakaznikID { get => zakaznikID; set => zakaznikID = value; }
        

        public Objednavka(int id, int zakaznikID)
        {
            ID = id;
            
            ZakaznikID = zakaznikID;
           
        }

        public Objednavka( int zakaznikID)
        {
            ID = 0;
            
            ZakaznikID = zakaznikID;
           
        }

        public Objednavka() { }

        public override string ToString()
        {
            return $"- Customer ID: {zakaznikID} -Odrde ID: {id}";

        }


    }
}
