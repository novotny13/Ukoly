﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal class ObjednavkaPolozkaDAO : IRepository<Objednavka_Polozka>
    {
 

        // Metoda pro vložení položky objednávky do databáze
        public void Insert(Objednavka_Polozka polozka)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("INSERT INTO Objednavka_Polozka (OrderID, ProductCISLO, Quantity) VALUES (@OrderID, @ProductCISLO)", conn))
            {
              
                command.Parameters.AddWithValue("@OrderID", polozka.OrderID);
                command.Parameters.AddWithValue("@ProductCISLO", polozka.ProductCISLO);
                
                command.ExecuteNonQuery();
            }
        }
        public void Insert2(int OrderID, int ProductID)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("INSERT INTO Objednavka_Polozka (OrderID, ProductCISLO, Quantity) VALUES (@OrderID, @ProductCISLO)", conn))
            {

                command.Parameters.AddWithValue("@OrderID", OrderID);
                command.Parameters.AddWithValue("@ProductCISLO", ProductID);

                command.ExecuteNonQuery();
            }
        }
        // Metoda pro smazání položky objednávky z databáze
        public void Delete(Objednavka_Polozka polozka)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("DELETE FROM Objednavka_Polozka WHERE OrderID = @OrderID AND ProductCISLO = @ProductCISLO", conn))
            {
                
                command.Parameters.AddWithValue("@OrderID", polozka.OrderID);
                command.Parameters.AddWithValue("@ProductCISLO", polozka.ProductCISLO);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro úpravu položky objednávky v databáze
        public void Update(Objednavka_Polozka polozka)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("UPDATE Objednavka_Polozka SET OrderID = 0  WHERE OrderID = @OrderID AND ProductCISLO = @ProductCISLO", conn))
            {
                
                command.Parameters.AddWithValue("@OrderID", polozka.OrderID);
                command.Parameters.AddWithValue("@ProductCISLO", polozka.ProductCISLO);
               
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro získání všech položek objednávky z databáze
        /*
        public IEnumerable<Objednavka_Polozka> GetAll()
        {
            List<Objednavka_Polozka> polozky = new List<Objednavka_Polozka>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Objednavka_Polozka";

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Objednavka_Polozka polozka = new Objednavka_Polozka
                        {
                            OrderID = (int)reader["OrderID"],
                            ProductID = (int)reader["ProductID"],
                            Quantity = (int)reader["Quantity"]
                        };
                        polozky.Add(polozka);
                    }
                }
            }

            return polozky;
        }
        */

        public IEnumerable<Objednavka_Polozka> GetAll()
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Objednavka_Polozka", conn))
            {


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Objednavka_Polozka polozka = new Objednavka_Polozka
                    {
                        OrderID = (int)reader["OrderID"],
                        ProductID = (int)reader["ProductID"],
                        Quantity = (int)reader["Quantity"]
                    };
                    yield return polozka;
                }

            }


        }
    }
}
