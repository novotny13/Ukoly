﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal class KategorieDAO : IRepository<Kategorie>
    {
        // Připojení k databázi
        

        // Metoda pro vložení kategorie do databáze
        public void Insert(Kategorie kategorie)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("INSERT INTO Kategorie (Name) VALUES (@Name)", conn))
            {
               
                command.Parameters.AddWithValue("@Name", kategorie.Name);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro smazání kategorie z databáze
        public void Delete(Kategorie kategorie)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("DELETE FROM Kategorie WHERE ID = @ID", conn))
            {

            
                command.Parameters.AddWithValue("@ID", kategorie.ID);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro úpravu kategorie v databáze
        public void Update(Kategorie kategorie)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("UPDATE Kategorie SET Name = @Name WHERE ID = @ID", conn))
            {
               
                command.Parameters.AddWithValue("@ID", kategorie.ID);
                command.Parameters.AddWithValue("@Name", kategorie.Name);
                command.ExecuteNonQuery();
            }
        }

        // Metoda pro získání všech kategorií z databáze
   

        public IEnumerable<Kategorie> GetAll()
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Kategorie", conn))
            {


                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Kategorie kategorie = new Kategorie
                    {
                        ID = (int)reader["ID"],
                        Name = (string)reader["Name"],
                       
                    };
                    yield return kategorie;
                }

            }


        }
    }
}
