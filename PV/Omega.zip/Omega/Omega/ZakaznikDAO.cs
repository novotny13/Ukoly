﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing.Text;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Omega
{
    internal class ZakaznikDAO : IRepository<Zakaznik>
    {
      

        
        public void Insert(Zakaznik zakaznik)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("INSERT INTO Zakaznik (Name, Email) VALUES (@Name, @Email)", conn))
            {
             
                command.Parameters.AddWithValue("@Name", zakaznik.Name);
                command.Parameters.AddWithValue("@Email", zakaznik.Email);
                command.ExecuteNonQuery();
            }
        }
        public int GetID(Zakaznik zakaznik)
        {
            int ID = 0;
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT ID from Zakaznik where Name = @Name and Email = @Email", conn))
            {

                command.Parameters.AddWithValue("@Name", zakaznik.Name);
                command.Parameters.AddWithValue("@Email", zakaznik.Email);
                command.ExecuteNonQuery();
                SqlDataReader reader = command.ExecuteReader();
               
                if (reader.Read())
                {
                    ID = (int)reader["ID"];

                }
            }
            return ID;
        }

        
        public void Delete(Zakaznik zakaznik)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("DELETE FROM Zakaznik WHERE ID = @ID", conn))
            {
             
                command.Parameters.AddWithValue("@ID", zakaznik.ID);
                command.ExecuteNonQuery();
            }
        }

        
        public void Update(Zakaznik customer)
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("UPDATE Zakaznik SET Name = @Name, Email = @Email WHERE ID = @ID", conn))
            {

                command.Parameters.AddWithValue("@ID", customer.ID);
                command.Parameters.AddWithValue("@Name", customer.Name);
                command.Parameters.AddWithValue("@Email", customer.Email);
                command.ExecuteNonQuery();
            }
        }

        
        public IEnumerable<Zakaznik> GetAll()
        {
            SqlConnection conn = DatabaseSingleton.GetInstance();

            using (SqlCommand command = new SqlCommand("SELECT * FROM Zakaznik", conn))
            {


                SqlDataReader reader = command.ExecuteReader();
                
                    while (reader.Read())
                    {
                        Zakaznik customer = new Zakaznik()
                        {
                            ID = (int)reader["ID"],
                            Name = (string)reader["Name"],
                            Email = (string)reader["Email"]
                        };
                        yield return customer;
                    }
                
            }

           
        }
    }

    
}
